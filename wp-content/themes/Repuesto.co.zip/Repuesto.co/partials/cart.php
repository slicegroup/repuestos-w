<div class="header-img-four">
    <div class="mask-item-img">
      <h3><?php the_title(); ?></h3>
    </div>
  </div>