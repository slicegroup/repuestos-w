  <section class="marcas ">
    <h3 class="work " style="padding-left: 65px ">Encuentra el
      <span class="word-color ">repuesto</span> indicado para la marca de tu
      <span class="word-color ">vehículo</span>
    </h3>
    <div class='container marcas-flex'>
      <div class="multiple-items-two ">
        <div class="card-marcas ">
          <img src="<?php echo get_template_directory_uri(); ?>/assets/img/marca1.jpg " alt=" ">
        </div>
        <div class="card-marcas ">
          <img src="<?php echo get_template_directory_uri(); ?>/assets/img/marca2.jpg " alt=" ">
        </div>
        <div class="card-marcas ">
          <img src="<?php echo get_template_directory_uri(); ?>/assets/img/marca3.png " alt=" ">
        </div>
        <div class="card-marcas ">
          <img src="<?php echo get_template_directory_uri(); ?>/assets/img/marca4.png " alt=" ">
        </div>
        <div class="card-marcas ">
          <img src="<?php echo get_template_directory_uri(); ?>/assets/img/marca5.png " alt=" ">
        </div>
        <div class="card-marcas ">
          <img src="<?php echo get_template_directory_uri(); ?>/assets/img/marca6.png " alt=" ">
        </div>
        <div class="card-marcas ">
          <img src="<?php echo get_template_directory_uri(); ?>/assets/img/marca2.jpg " alt=" ">
        </div>
        <div class="card-marcas ">
          <img src="<?php echo get_template_directory_uri(); ?>/assets/img/marca3.png " alt=" ">
        </div>
        <div class="card-marcas ">
          <img src="<?php echo get_template_directory_uri(); ?>/assets/img/marca4.png " alt=" ">
        </div>
      </div>
    </div>
  </section>
  