  <section class="widget">
    <!-- <div class="img-back-two">
      <img src="<?php echo get_template_directory_uri(); ?>/assets/img/search-engine.svg">
    </div> -->

    <div class="nav-search-classi-content">
      <div class="nav-search-classi__section sec-one">
        <div>
          <select id="category__l2" name="9991744-AMCO_1744_1" class="category-filter category-dynamic" tabindex="11" style="display: block; width: 421px; ">
            <option value=" ">Todas las marcas</option>
            <option value="9991744-AMCO_1744_1-MMCO16035 ">Acura</option>
            <option value="9991744-AMCO_1744_1-MMCO18277 ">Alfa Romeo</option>
            <option value="9991744-AMCO_1744_1-MMCO18278 ">Aro</option>
            <option value="9991744-AMCO_1744_1-MMCO18766 ">Asia</option>
            <option value="9991744-AMCO_1744_1-MMCO116597 ">Aston Martin</option>
            <option value="9991744-AMCO_1744_1-MMCO11816 ">Audi</option>
            <option value="9991744-AMCO_1744_1-MMCO11814 ">BMW</option>
            <option value="9991744-AMCO_1744_1-MMCO16034 ">BYD</option>
            <option value="9991744-AMCO_1744_1-MMCO64671 ">Baic</option>
            <option value="9991744-AMCO_1744_1-MMCO44630 ">Brilliance</option>
            <option value="9991744-AMCO_1744_1-MMCO16033 ">Buick</option>
            <option value="9991744-AMCO_1744_1-MMCO20505 ">Cadillac</option>
            <option value="9991744-AMCO_1744_1-MMCO16037 ">Chana</option>
            <option value="9991744-AMCO_1744_1-MMCO18283 ">Changan</option>
            <option value="9991744-AMCO_1744_1-MMCO18285 ">Changhe</option>
            <option value="9991744-AMCO_1744_1-MMCO16913 ">Chery</option>
            <option value="9991744-AMCO_1744_1-MMCO6433 ">Chevrolet</option>
            <option value="9991744-AMCO_1744_1-MMCO18811 ">Chrysler</option>
            <option value="9991744-AMCO_1744_1-MMCO11800 ">Citroën</option>
            <option value="9991744-AMCO_1744_1-MMCO18805 ">DFM/DFSK</option>
            <option value="9991744-AMCO_1744_1-MMCO90308 ">DS</option>
            <option value="9991744-AMCO_1744_1-MMCO6434 ">Daewoo</option>
            <option value="9991744-AMCO_1744_1-MMCO11826 ">Daihatsu</option>
            <option value="9991744-AMCO_1744_1-MMCO18814 ">Dodge</option>
            <option value="9991744-AMCO_1744_1-MMCO77130 ">FAW</option>
            <option value="9991744-AMCO_1744_1-MMCO6435 ">Fiat</option>
            <option value="9991744-AMCO_1744_1-MMCO6436 ">Ford</option>
            <option value="9991744-AMCO_1744_1-MMCO52245 ">Foton</option>
            <option value="9991744-AMCO_1744_1-MMCO18845 ">GMC</option>
            <option value="9991744-AMCO_1744_1-MMCO16048 ">Geely</option>
            <option value="9991744-AMCO_1744_1-MMCO18847 ">Gonow</option>
            <option value="9991744-AMCO_1744_1-MMCO18846 ">Great Wall</option>
            <option value="9991744-AMCO_1744_1-MMCO18849 ">Hafei</option>
            <option value="9991744-AMCO_1744_1-MMCO37124 ">Haima</option>
            <option value="9991744-AMCO_1744_1-MMCO111780 ">Haval</option>
            <option value="9991744-AMCO_1744_1-MMCO18288 ">Hino</option>
            <option value="9991744-AMCO_1744_1-MMCO6437 ">Honda</option>
            <option value="9991744-AMCO_1744_1-MMCO18859 ">Hummer</option>
            <option value="9991744-AMCO_1744_1-MMCO6438 ">Hyundai</option>
            <option value="9991744-AMCO_1744_1-MMCO18289 ">Infiniti</option>
            <option value="9991744-AMCO_1744_1-MMCO18857 ">International</option>
            <option value="9991744-AMCO_1744_1-MMCO18867 ">Isuzu</option>
            <option value="9991744-AMCO_1744_1-MMCO18290 ">Iveco</option>
            <option value="9991744-AMCO_1744_1-MMCO35918 ">JAC</option>
            <option value="9991744-AMCO_1744_1-MMCO16053 ">Jaguar</option>
            <option value="9991744-AMCO_1744_1-MMCO18875 ">Jeep</option>
            <option value="9991744-AMCO_1744_1-MMCO18291 ">Jmc</option>
            <option value="9991744-AMCO_1744_1-MMCO11965 ">Kia</option>
            <option value="9991744-AMCO_1744_1-MMCO14043 ">Lada</option>
            <option value="9991744-AMCO_1744_1-MMCO18889 ">Land Rover</option>
            <option value="9991744-AMCO_1744_1-MMCO18292 ">Landwind</option>
            <option value="9991744-AMCO_1744_1-MMCO16043 ">Lexus</option>
            <option value="9991744-AMCO_1744_1-MMCO28425 ">Lifan</option>
            <option value="9991744-AMCO_1744_1-MMCO18293 ">Lincoln</option>
            <option value="9991744-AMCO_1744_1-MMCO18294 ">MG</option>
            <option value="9991744-AMCO_1744_1-MMCO38756 ">Mahindra</option>
            <option value="9991744-AMCO_1744_1-MMCO37135 ">Maserati</option>
            <option value="9991744-AMCO_1744_1-MMCO6439 ">Mazda</option>
            <option value="9991744-AMCO_1744_1-MMCO6440 ">Mercedes Benz</option>
            <option value="9991744-AMCO_1744_1-MMCO16061 ">Mini</option>
            <option value="9991744-AMCO_1744_1-MMCO6441 ">Mitsubishi</option>
            <option value="9991744-AMCO_1744_1-MMCO6442 ">Nissan</option>
            <option value="9991744-AMCO_1744_1-MMCO18296 ">Opel</option>
            <option value="9991744-AMCO_1744_1-MMCO6443 ">Otras Marcas</option>
            <option value="9991744-AMCO_1744_1-MMCO6444 ">Peugeot</option>
            <option value="9991744-AMCO_1744_1-MMCO18297 ">Plymouth</option>
            <option value="9991744-AMCO_1744_1-MMCO16063 ">Pontiac</option>
            <option value="9991744-AMCO_1744_1-MMCO16948 ">Porsche</option>
            <option value="9991744-AMCO_1744_1-MMCO111503 ">RAM</option>
            <option value="9991744-AMCO_1744_1-MMCO6445 ">Renault</option>
            <option value="9991744-AMCO_1744_1-MMCO16069 ">Rover</option>
            <option value="9991744-AMCO_1744_1-MMCO11975 ">Seat</option>
            <option value="9991744-AMCO_1744_1-MMCO15592 ">Skoda</option>
            <option value="9991744-AMCO_1744_1-MMCO111781 ">Soueast</option>
            <option value="9991744-AMCO_1744_1-MMCO11831 ">Ssangyong</option>
            <option value="9991744-AMCO_1744_1-MMCO11845 ">Subaru</option>
            <option value="9991744-AMCO_1744_1-MMCO11830 ">Suzuki</option>
            <option value="9991744-AMCO_1744_1-MMCO119969 ">Tesla</option>
            <option value="9991744-AMCO_1744_1-MMCO6446 ">Toyota</option>
            <option value="9991744-AMCO_1744_1-MMCO6447 ">Volkswagen</option>
            <option value="9991744-AMCO_1744_1-MMCO16072 ">Volvo</option>
            <option value="9991744-AMCO_1744_1-MMCO18971 ">Wuling</option>
            <option value="9991744-AMCO_1744_1-MMCO18978 ">Zhongxing</option>
            <option value="9991744-AMCO_1744_1-MMCO18979 ">Zotye</option>
          </select>
        </div>
        <div>
          <select id="category__l3 " name="category__l3 " class="category-filter category-dynamic " tabindex="12
            " disabled=" " style="display: block; width: 421px;  margin-left: 10px;">
            <option value=" ">Todos los modelos</option>
          </select>
        </div>
      </div>

      <div class="nav-search-classi__section ">


        <div class="nav-search-classi__range-filter ">
          <select id="price-filter-from " name="price_from " class="range-filter range-filter-from " tabindex="100 " style="  border-right: 1px solid #ccc;">
            <option value=" ">Precio desde</option>
            <option value="1 ">Sin precio mínimo</option>
            <option value="50000000 ">$ 50.000.000</option>
            <option value="100000000 ">$ 100.000.000</option>
            <option value="150000000 ">$ 150.000.000</option>
            <option value="200000000 ">$ 200.000.000</option>
            <option value="250000000 ">$ 250.000.000</option>
            <option value="300000000 ">$ 300.000.000</option>
            <option value="350000000 ">$ 350.000.000</option>
            <option value="400000000 ">$ 400.000.000</option>
            <option value="450000000 ">$ 450.000.000</option>
            <option value="500000000 ">$ 500.000.000</option>
            <option value="550000000 ">$ 550.000.000</option>
            <option value="600000000 ">$ 600.000.000</option>
            <option value="650000000 ">$ 650.000.000</option>
            <option value="700000000 ">$ 700.000.000</option>
          </select>
          <select id="price-filter-to " name="price_to " class="range-filter range-filter-to " tabindex="101 ">
            <option value=" ">Precio hasta</option>
            <option value="50000000 ">$ 50.000.000</option>
            <option value="100000000 ">$ 100.000.000</option>
            <option value="150000000 ">$ 150.000.000</option>
            <option value="200000000 ">$ 200.000.000</option>
            <option value="250000000 ">$ 250.000.000</option>
            <option value="300000000 ">$ 300.000.000</option>
            <option value="350000000 ">$ 350.000.000</option>
            <option value="400000000 ">$ 400.000.000</option>
            <option value="450000000 ">$ 450.000.000</option>
            <option value="500000000 ">$ 500.000.000</option>
            <option value="550000000 ">$ 550.000.000</option>
            <option value="600000000 ">$ 600.000.000</option>
            <option value="650000000 ">$ 650.000.000</option>
            <option value="700000000 ">$ 700.000.000</option>
            <option value="0 ">Sin precio máximo</option>
          </select>
        </div>
        <div class="nav-search-classi__range-filter ">
          <select id="year-filter-from " name="years_from " class="range-filter range-filter-from " tabindex="102 " style="    border-right: 1px solid #ccc;">
            <option value=" ">Año desde</option>
            <option value="2020 ">2020</option>
            <option value="2019 ">2019</option>
            <option value="2018 ">2018</option>
            <option value="2017 ">2017</option>
            <option value="2016 ">2016</option>
            <option value="2015 ">2015</option>
            <option value="2014 ">2014</option>
            <option value="2013 ">2013</option>
            <option value="2012 ">2012</option>
            <option value="2011 ">2011</option>
            <option value="2010 ">2010</option>
            <option value="2009 ">2009</option>
            <option value="2008 ">2008</option>
            <option value="2007 ">2007</option>
            <option value="2006 ">2006</option>
            <option value="2005 ">2005</option>
            <option value="2004 ">2004</option>
            <option value="2003 ">2003</option>
            <option value="2002 ">2002</option>
            <option value="2001 ">2001</option>
            <option value="2000 ">2000</option>
            <option value="1999 ">1999</option>
            <option value="1998 ">1998</option>
            <option value="1997 ">1997</option>
            <option value="1996 ">1996</option>
            <option value="1995 ">1995</option>
            <option value="1994 ">1994</option>
            <option value="1993 ">1993</option>
            <option value="1992 ">1992</option>
            <option value="1991 ">1991</option>
            <option value="1990 ">1990</option>
            <option value="1989 ">1989</option>
            <option value="1988 ">1988</option>
            <option value="1987 ">1987</option>
            <option value="1986 ">1986</option>
            <option value="1985 ">1985</option>
            <option value="1984 ">1984</option>
            <option value="1983 ">1983</option>
            <option value="1982 ">1982</option>
            <option value="1981 ">1981</option>
            <option value="1980 ">1980</option>
            <option value="1979 ">1979</option>
            <option value="1978 ">1978</option>
            <option value="1977 ">1977</option>
            <option value="1976 ">1976</option>
            <option value="1975 ">1975</option>
            <option value="1974 ">1974</option>
            <option value="1973 ">1973</option>
            <option value="1972 ">1972</option>
            <option value="1971 ">1971</option>
            <option value="1970 ">1970</option>
            <option value="1969 ">1969</option>
            <option value="1968 ">1968</option>
            <option value="1967 ">1967</option>
            <option value="1966 ">1966</option>
            <option value="1965 ">1965</option>
            <option value="1964 ">1964</option>
            <option value="1963 ">1963</option>
            <option value="1962 ">1962</option>
            <option value="1961 ">1961</option>
            <option value="1960 ">1960</option>
            <option value="1959 ">1959</option>
            <option value="1957 ">1957</option>
            <option value="1956 ">1956</option>
            <option value="1955 ">1955</option>
            <option value="1954 ">1954</option>
            <option value="1953 ">1953</option>
            <option value="1952 ">1952</option>
            <option value="1950 ">1950</option>
            <option value="1948 ">1948</option>
            <option value="1946 ">1946</option>
            <option value="1942 ">1942</option>
            <option value="1937 ">1937</option>
            <option value="1915 ">1915</option>
          </select>
          <select id="year-filter-to " name="years_to " class="range-filter range-filter-to " tabindex="103 ">
            <option value=" ">Año hasta</option>
            <option value="2020 ">2020</option>
            <option value="2019 ">2019</option>
            <option value="2018 ">2018</option>
            <option value="2017 ">2017</option>
            <option value="2016 ">2016</option>
            <option value="2015 ">2015</option>
            <option value="2014 ">2014</option>
            <option value="2013 ">2013</option>
            <option value="2012 ">2012</option>
            <option value="2011 ">2011</option>
            <option value="2010 ">2010</option>
            <option value="2009 ">2009</option>
            <option value="2008 ">2008</option>
            <option value="2007 ">2007</option>
            <option value="2006 ">2006</option>
            <option value="2005 ">2005</option>
            <option value="2004 ">2004</option>
            <option value="2003 ">2003</option>
            <option value="2002 ">2002</option>
            <option value="2001 ">2001</option>
            <option value="2000 ">2000</option>
            <option value="1999 ">1999</option>
            <option value="1998 ">1998</option>
            <option value="1997 ">1997</option>
            <option value="1996 ">1996</option>
            <option value="1995 ">1995</option>
            <option value="1994 ">1994</option>
            <option value="1993 ">1993</option>
            <option value="1992 ">1992</option>
            <option value="1991 ">1991</option>
            <option value="1990 ">1990</option>
            <option value="1989 ">1989</option>
            <option value="1988 ">1988</option>
            <option value="1987 ">1987</option>
            <option value="1986 ">1986</option>
            <option value="1985 ">1985</option>
            <option value="1984 ">1984</option>
            <option value="1983 ">1983</option>
            <option value="1982 ">1982</option>
            <option value="1981 ">1981</option>
            <option value="1980 ">1980</option>
            <option value="1979 ">1979</option>
            <option value="1978 ">1978</option>
            <option value="1977 ">1977</option>
            <option value="1976 ">1976</option>
            <option value="1975 ">1975</option>
            <option value="1974 ">1974</option>
            <option value="1973 ">1973</option>
            <option value="1972 ">1972</option>
            <option value="1971 ">1971</option>
            <option value="1970 ">1970</option>
            <option value="1969 ">1969</option>
            <option value="1968 ">1968</option>
            <option value="1967 ">1967</option>
            <option value="1966 ">1966</option>
            <option value="1965 ">1965</option>
            <option value="1964 ">1964</option>
            <option value="1963 ">1963</option>
            <option value="1962 ">1962</option>
            <option value="1961 ">1961</option>
            <option value="1960 ">1960</option>
            <option value="1959 ">1959</option>
            <option value="1957 ">1957</option>
            <option value="1956 ">1956</option>
            <option value="1955 ">1955</option>
            <option value="1954 ">1954</option>
            <option value="1953 ">1953</option>
            <option value="1952 ">1952</option>
            <option value="1950 ">1950</option>
            <option value="1948 ">1948</option>
            <option value="1946 ">1946</option>
            <option value="1942 ">1942</option>
            <option value="1937 ">1937</option>
            <option value="1915 ">1915</option>
          </select>
        </div>

      </div>
      <div class="btn-see ">
        <button type="button " class="btn-primary site-button btn-block ">Buscar </button>
      </div>
    </div>

  </section>