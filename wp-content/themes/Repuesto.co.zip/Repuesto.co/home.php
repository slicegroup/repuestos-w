<?php get_header(); ?>
  <!-- end of navbar-->
  <!-- banner section -->
<?php  get_template_part('partials/banner'); ?>
    <!--banner section end -->
 <?php  get_template_part('partials/widget'); ?>
<?php  get_template_part('partials/product-stock'); ?>
<?php  get_template_part('partials/lo-necesario'); ?>
<?php  get_template_part('partials/about'); ?>
<?php  get_template_part('partials/repuestos'); ?>
<?php  get_template_part('partials/contact'); ?>
<?php get_footer(); ?>






