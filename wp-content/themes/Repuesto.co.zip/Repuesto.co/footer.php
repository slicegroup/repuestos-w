  <footer class="copy ">
    <p>Copyright © REPUESTOS.CO 2019 | Powered by
      <a href="https://slicegroup.co/ " target="_blank ">
        <img src="<?php echo get_template_directory_uri(); ?>/assets/img/slice.svg ">
      </a>
    </p>
  </footer>
  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js "></script>
  <script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js "></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/latest/TweenMax.min.js "></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js "></script>
  <script src="https://code.jquery.com/jquery-3.3.1.min.js " crossorigin="anonymous "></script>
  <link rel="stylesheet " href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css ">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js " crossorigin="anonymous "></script>
  <script src='https://www.google.com/recaptcha/api.js'></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js " crossorigin="anonymous "></script>
  <script src="<?php echo get_template_directory_uri(); ?>/assets/js/wow.js "></script>
  <script src="<?php echo get_template_directory_uri(); ?>/assets/js/slick.min.js "></script>
  <script src="<?php echo get_template_directory_uri(); ?>/assets/js/setting.js "></script>
  <script type="text/javascript " src="<?php echo get_template_directory_uri(); ?>/assets/js/main.js "></script>
<?php wp_footer(); ?>
</body>

</html> 




