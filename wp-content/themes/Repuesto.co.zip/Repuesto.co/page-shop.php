 <?php get_header(); ?>
 <div class="header-img-four">
    <div class="mask-item-img">
      <h3>Resultados</h3>
    </div>
  </div>

  <?php  get_template_part('partials/contact'); ?>
  <div class="img-footer">
    <img src="<?php echo get_template_directory_uri(); ?>/assets/img/car-footer.svg" alt="">
  </div>


<?php get_footer(); ?>
